package com.example.jobset8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
